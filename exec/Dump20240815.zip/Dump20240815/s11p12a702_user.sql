-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a702
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `is_agent` bit(1) NOT NULL,
  `oauth_google` bit(1) NOT NULL,
  `oauth_kakao` bit(1) NOT NULL,
  `oauth_naver` bit(1) NOT NULL,
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(10) NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UKob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (_binary '\0',_binary '\0',_binary '\0',_binary '\0',1,'임차인1','01011111111','user1@example.com','임차인1','$2a$10$pMigPcxlsGvC8LWPBwmWOuvREexVraNhCUANj2WOZa75V2bINhbg6','https://d3q1v38zegevi7.cloudfront.net/user/f90c94c1b72342e9a8122d5b08e5fcd5_images%20%281%29.jfif'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',2,'임차인2','01011112222','user2@example.com','임차인2','$2a$10$3kbl7ocwawZN2Q0rYnecPOHjUJfX2MGgKy42R2qsCLDvMkrMEQYBW','https://d3q1v38zegevi7.cloudfront.net/user/0a5d968403034adb8bae293a08542622_images%20%282%29.jfif'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',3,'임차인3','01011113333','user3@example.com','임차인3','$2a$10$ptjuA9gpyTYtAkq5ou4awO9qeHcuTfjgABGhl1Fw6C9XewOgxbbv.','https://d3q1v38zegevi7.cloudfront.net/user/daef3dc1dcd14ba696ddbf79159cc61f_images%20%283%29.jfif'),(_binary '',_binary '\0',_binary '\0',_binary '\0',4,'중개인1','01022221111','agent1@example.com','중개인1','$2a$10$Ci.1Uwgjq0SZHJJGYahNPuwGHoXvdFOu6ZDPifUlwAwXAPvQFVZP2','https://d3q1v38zegevi7.cloudfront.net/user/e4a7baadc7284aa1a218766ff3a42483_1.jpg'),(_binary '',_binary '\0',_binary '\0',_binary '\0',5,'중개인2','01022222222','agent2@example.com','중개인2','$2a$10$xnmI4pE5wZMO5TwRQLLda.RakC4DZfQtzq1mQNTrUnlqg0ncqIazG','https://d3q1v38zegevi7.cloudfront.net/user/2df35e8d202d498590883c1b5f386ca7_2.jpg'),(_binary '',_binary '\0',_binary '\0',_binary '\0',6,'중개인3','01022223333','agent3@example.com','중개인3','$2a$10$Bsh2QU2w7e1up0ZGq/WhTulve02phFcL.t88RSTS.r9XL64Oi6olC','https://d3q1v38zegevi7.cloudfront.net/user/cf69b772bcd6468c85c443d88509bdee_3.png');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:04:28
