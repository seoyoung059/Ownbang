-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a702
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `reservation_id` int(10) unsigned NOT NULL,
  `video_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `video_url` varchar(255) NOT NULL,
  `video_status` enum('ENCODING','RECORDED','RECORDING') NOT NULL,
  PRIMARY KEY (`video_id`),
  UNIQUE KEY `UKcs2ju6pf9u0ce52ytg2irqbd3` (`reservation_id`),
  CONSTRAINT `FK8hl17ijogyo8tvfklbqe2aap7` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`reservation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (1,1,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_Spqb8RRywk/ses_Spqb8RRywk.m3u8','RECORDED'),(4,2,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_HdwZAhC75s/ses_HdwZAhC75s.m3u8','RECORDED'),(6,3,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_HdwZAhC75s/ses_HdwZAhC75s.m3u8','RECORDED'),(7,4,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_EGXTCpeFVk/ses_EGXTCpeFVk.m3u8','RECORDED'),(11,5,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_Spqb8RRywk/ses_Spqb8RRywk.m3u8','RECORDED'),(12,6,'https://d3q1v38zegevi7.cloudfront.net/videos/ses_EGXTCpeFVk/ses_EGXTCpeFVk.m3u8','RECORDED');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:04:28
