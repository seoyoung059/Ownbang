-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a702
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room_image`
--

DROP TABLE IF EXISTS `room_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `room_image_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcme41omxvwoj00bhqk7fwt70v` (`room_id`),
  CONSTRAINT `FKcme41omxvwoj00bhqk7fwt70v` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_image`
--

LOCK TABLES `room_image` WRITE;
/*!40000 ALTER TABLE `room_image` DISABLE KEYS */;
INSERT INTO `room_image` VALUES (1,1,'https://d3q1v38zegevi7.cloudfront.net/roomImages/2f64a5794b064c58ba1e748fcc854bf9_room202.jpg'),(2,1,'https://d3q1v38zegevi7.cloudfront.net/roomImages/ca579f0c86ae4f8aaa3b557a4f0baadb_room301.jpg'),(3,2,'https://d3q1v38zegevi7.cloudfront.net/roomImages/73c4f2a52d68440ab3757c6a95ebd16b_room302.jpg'),(4,2,'https://d3q1v38zegevi7.cloudfront.net/roomImages/fe135a61490f4752b8147e64d01b1ee2_room303.jpg'),(5,3,'https://d3q1v38zegevi7.cloudfront.net/roomImages/dd7d27850fc94a86be6c1f9aba7b6e79_room.jfif'),(6,3,'https://d3q1v38zegevi7.cloudfront.net/roomImages/66ac91e95d1344e8bcb51ed4439a98f2_11.jpg'),(7,4,'https://d3q1v38zegevi7.cloudfront.net/roomImages/8411e8b17c2947c38698c24d1828ca1c_22.jpg'),(8,4,'https://d3q1v38zegevi7.cloudfront.net/roomImages/0b4325fd96024a51b7e695d218ff70d4_11.jpg'),(9,5,'https://d3q1v38zegevi7.cloudfront.net/roomImages/dcbda561e72e41b6abf3a5e184da28f5_333.jpg'),(10,5,'https://d3q1v38zegevi7.cloudfront.net/roomImages/565075b737d744789a930c586b1cefd5_11.jpg'),(11,6,'https://d3q1v38zegevi7.cloudfront.net/roomImages/963a6236185940de9204d7522fbda7dd_2024071517512343_17616_wt.jpg'),(12,6,'https://d3q1v38zegevi7.cloudfront.net/roomImages/4045d70453e84b29845e9d846b6c07f0_444.jpg'),(13,7,'https://d3q1v38zegevi7.cloudfront.net/roomImages/59530364435f4d639b055c86b6d74fb2_KakaoTalk_20240330_143701544_06.jpg'),(14,7,'https://d3q1v38zegevi7.cloudfront.net/roomImages/8ecef71cb48b4188822b6baa803ccf48_11.jpg'),(15,8,'https://d3q1v38zegevi7.cloudfront.net/roomImages/717d6efd6b934d4e86ebed749c607384_GOPR3719.jfif'),(16,8,'https://d3q1v38zegevi7.cloudfront.net/roomImages/745708dad7fc40d180b4af46435b7d3a_11.jpg'),(17,9,'https://d3q1v38zegevi7.cloudfront.net/roomImages/65e745fc55af439c9d061d1755958d48_2024071911420627_17616_wt.jpg'),(18,9,'https://d3q1v38zegevi7.cloudfront.net/roomImages/f051f185e985421492582ce99ccba328_photoinfra_1545016313742.jpg'),(19,10,'https://d3q1v38zegevi7.cloudfront.net/roomImages/507deb495ad54b6691765f784c689ff4_1719911428036050.jpg'),(20,10,'https://d3q1v38zegevi7.cloudfront.net/roomImages/209b87087de24fc8972a73fe3c454573_photoinfra_1545016313742.jpg'),(21,11,'https://d3q1v38zegevi7.cloudfront.net/roomImages/24a43208021748caa8248fc785e9b9b1_1719911468164551.jpg'),(22,11,'https://d3q1v38zegevi7.cloudfront.net/roomImages/941b91db654d48dcb7f873ff8ce00aef_11.jpg'),(23,12,'https://d3q1v38zegevi7.cloudfront.net/roomImages/b8aa03c04c794c0fade47b3fac3d01da_KakaoTalk_20240426_120008998.jpg'),(24,12,'https://d3q1v38zegevi7.cloudfront.net/roomImages/cdf6a5baeabc4dcaa6c50961b8a19644_444.jpg'),(25,13,'https://d3q1v38zegevi7.cloudfront.net/roomImages/0cf0b06afd8c41ef9a9ef8d33841a9da_KakaoTalk_20240426_120008998_03.jpg'),(26,13,'https://d3q1v38zegevi7.cloudfront.net/roomImages/15c0e2ddf4a8443f8922eda45356ba90_444.jpg'),(27,14,'https://d3q1v38zegevi7.cloudfront.net/roomImages/8e9e0171bea44f908bcd4476f0e2b887_1718412744540739.jpg'),(28,14,'https://d3q1v38zegevi7.cloudfront.net/roomImages/f36b03d83ae3474e9bc18e36fa1a70b2_photoinfra_1545016313742.jpg'),(29,15,'https://d3q1v38zegevi7.cloudfront.net/roomImages/9dce2768666e4bf09bc2ab30d8a4541f_1719911428036050.jpg'),(30,15,'https://d3q1v38zegevi7.cloudfront.net/roomImages/a8ce73fe020c4d2a9330c91d114ba009_444.jpg'),(31,16,'https://d3q1v38zegevi7.cloudfront.net/roomImages/a22b2f3812bd436eafcfc611171a1563_1718412745132824.jpg'),(32,16,'https://d3q1v38zegevi7.cloudfront.net/roomImages/e4a66f92464c48e5a0cbadd96601cb0c_444.jpg'),(33,17,'https://d3q1v38zegevi7.cloudfront.net/roomImages/778e242c153646d0869e276ab4894274_S_92551712298774uo.jpg'),(34,17,'https://d3q1v38zegevi7.cloudfront.net/roomImages/2c68eaf0e67b48ec8e336484db0f69b2_KakaoTalk_20240426_120026269_02.jpg'),(35,18,'https://d3q1v38zegevi7.cloudfront.net/roomImages/df908752fbcb401d90597fa17308795c_20240426_114932.jpg'),(36,18,'https://d3q1v38zegevi7.cloudfront.net/roomImages/28e32f782ca14137b8114986a096e3a5_KakaoTalk_20240330_143701544_11.jpg'),(37,19,'https://d3q1v38zegevi7.cloudfront.net/roomImages/059940962b9740d8b1fa1664cde21d98_3889bba6947a78857b8e3813371db3d56f1033d2.jpg'),(38,19,'https://d3q1v38zegevi7.cloudfront.net/roomImages/e99ebdc0f4e245bb84c2a4424c999877_room1.jpg'),(39,20,'https://d3q1v38zegevi7.cloudfront.net/roomImages/a4b31e8cd57e469e9e84507425a1e507_2024071911420627_17616_wt.jpg'),(40,20,'https://d3q1v38zegevi7.cloudfront.net/roomImages/73c5ad767ec842fa904c4078991c639c_photoinfra_1545016313742.jpg'),(41,21,'https://d3q1v38zegevi7.cloudfront.net/roomImages/01ad9b6b9bd34820824d6cecb4c3911d_2024071517512343_17616_wt.jpg'),(42,21,'https://d3q1v38zegevi7.cloudfront.net/roomImages/b95a3e1992b8488fa101c5fa178ce47b_11.jpg'),(43,22,'https://d3q1v38zegevi7.cloudfront.net/roomImages/cfc186f4f5ba49ea927f64180ae86598_KakaoTalk_20240330_143701544_06.jpg'),(44,22,'https://d3q1v38zegevi7.cloudfront.net/roomImages/312443bfce3b4d4cb1d6e3643fee92eb_444.jpg'),(45,23,'https://d3q1v38zegevi7.cloudfront.net/roomImages/d076727db8c8482ca384e6ded4c7832b_1719911468164551.jpg'),(46,23,'https://d3q1v38zegevi7.cloudfront.net/roomImages/8b18e1926e2041538038a59a6c5d29c0_1719911428036050.jpg'),(47,24,'https://d3q1v38zegevi7.cloudfront.net/roomImages/bdc90a0c03f14a9c9943be1cb4e013cf_KakaoTalk_20240330_143701544_06.jpg'),(48,24,'https://d3q1v38zegevi7.cloudfront.net/roomImages/852ebea26ef143218ca5eaf5a43bf7c7_2024071517512343_17616_wt.jpg');
/*!40000 ALTER TABLE `room_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:04:26
