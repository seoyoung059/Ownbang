-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a702
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `exclusive_area` float(5,2) NOT NULL,
  `is_loft` bit(1) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `room_floor` tinyint(4) NOT NULL,
  `supply_area` float(5,2) NOT NULL,
  `agent_id` int(10) unsigned NOT NULL,
  `deposit` int(10) unsigned DEFAULT NULL,
  `maintenance_fee` int(10) unsigned NOT NULL,
  `monthly_rent` int(10) unsigned DEFAULT NULL,
  `room_appliances_id` int(10) unsigned NOT NULL,
  `room_detail_id` int(10) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `detail_address` varchar(255) NOT NULL,
  `geo_hash` varchar(255) DEFAULT NULL,
  `parcel` varchar(255) NOT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `road` varchar(255) NOT NULL,
  `deal_type` enum('JEONSE','MONTHLY') NOT NULL,
  `room_type` enum('FLAT','OFFICE') NOT NULL,
  `structure` enum('ONEROOM','SEPERATED','THREEROOM','TWOROOM') NOT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `UK1355g7qypebpmamyu3pe73y2q` (`room_appliances_id`),
  UNIQUE KEY `UK5bt6bgm4r16s83faiieeel04o` (`room_detail_id`),
  KEY `FKiyysq54cgwlicufj4iekvdsec` (`agent_id`),
  CONSTRAINT `FKe0cxgoac7v92s0ugjocyte1hy` FOREIGN KEY (`room_detail_id`) REFERENCES `room_detail` (`room_detail_id`),
  CONSTRAINT `FKiyysq54cgwlicufj4iekvdsec` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`agent_id`),
  CONSTRAINT `FKrrew7updmfo1c5gtmty708xtd` FOREIGN KEY (`room_appliances_id`) REFERENCES `room_appliances` (`room_appliances_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (18.22,_binary '\0',37.4865,127.034,4,29.64,1,1500,15,70,1,1,1,'1동 403호','wydm68pn8','서울 강남구 도곡동 952','https://d3q1v38zegevi7.cloudfront.net/roomImages/2f64a5794b064c58ba1e748fcc854bf9_room202.jpg','서울 강남구 강남대로 256','MONTHLY','OFFICE','ONEROOM'),(18.57,_binary '\0',37.4934,127.032,2,36.50,1,2000,15,75,2,2,2,'101동 201호','wydm69qp0','','https://d3q1v38zegevi7.cloudfront.net/roomImages/73c4f2a52d68440ab3757c6a95ebd16b_room302.jpg','서울 강남구 역삼로 118','MONTHLY','OFFICE','ONEROOM'),(26.92,_binary '\0',37.5011,127.054,11,39.36,1,1200,13,87,3,3,3,'1103호','wydm74vg9','서울 강남구 대치동 910-16','https://d3q1v38zegevi7.cloudfront.net/roomImages/dd7d27850fc94a86be6c1f9aba7b6e79_room.jfif','서울 강남구 역삼로70길 5','MONTHLY','OFFICE','ONEROOM'),(28.38,_binary '\0',37.5028,127.057,2,42.38,1,3000,15,120,4,4,4,'101동 201호','wydm75pvg','서울 강남구 대치동 903-35','https://d3q1v38zegevi7.cloudfront.net/roomImages/8411e8b17c2947c38698c24d1828ca1c_22.jpg','서울 강남구 역삼로77길 2','MONTHLY','OFFICE','TWOROOM'),(26.92,_binary '\0',37.4696,127.04,4,39.36,1,2000,8,90,5,5,5,'1동 403호','wydm4v5sr','서울 서초구 양재동 317-5','https://d3q1v38zegevi7.cloudfront.net/roomImages/dcbda561e72e41b6abf3a5e184da28f5_333.jpg','서울 서초구 강남대로12길 11','MONTHLY','FLAT','TWOROOM'),(18.22,_binary '\0',37.4688,127.041,8,22.00,1,2000,14,70,6,6,6,'102동 804호','wydm4uuxm','서울 서초구 양재동 329-10','https://d3q1v38zegevi7.cloudfront.net/roomImages/963a6236185940de9204d7522fbda7dd_2024071517512343_17616_wt.jpg','서울 서초구 강남대로8길 15-18','MONTHLY','OFFICE','ONEROOM'),(26.92,_binary '\0',37.5075,127.024,1,36.50,1,1000,15,90,7,7,7,'201동 103호','wydm6kpby','서울 강남구 논현동 165-19','https://d3q1v38zegevi7.cloudfront.net/roomImages/59530364435f4d639b055c86b6d74fb2_KakaoTalk_20240330_143701544_06.jpg','서울 강남구 강남대로122길 6','MONTHLY','OFFICE','ONEROOM'),(26.92,_binary '\0',37.5574,126.977,4,45.79,1,1000,10,67,8,8,8,'1동 411호','wydm9mn5t','서울 중구 남창동 205-38','https://d3q1v38zegevi7.cloudfront.net/roomImages/717d6efd6b934d4e86ebed749c607384_GOPR3719.jfif','서울 중구 퇴계로4길 2-1','MONTHLY','OFFICE','ONEROOM'),(18.22,_binary '\0',37.5252,127.001,8,29.64,2,2000,13,70,9,9,9,'103동 802호','wydm3zpxc','서울 용산구 보광동 120','https://d3q1v38zegevi7.cloudfront.net/roomImages/65e745fc55af439c9d061d1755958d48_2024071911420627_17616_wt.jpg','서울 용산구 보광로 3-8','MONTHLY','OFFICE','ONEROOM'),(23.68,_binary '\0',37.5257,127.001,2,39.36,2,2000,10,60,10,10,10,'203호','wydm3zr5h','서울 용산구 보광동 160-1','https://d3q1v38zegevi7.cloudfront.net/roomImages/507deb495ad54b6691765f784c689ff4_1719911428036050.jpg','서울 용산구 보광로7길 5','MONTHLY','OFFICE','TWOROOM'),(22.79,_binary '\0',37.5266,127.001,4,36.50,2,2000,10,110,11,11,11,'1동 403호','wydm3zx22','서울 용산구 보광동 80-32','https://d3q1v38zegevi7.cloudfront.net/roomImages/24a43208021748caa8248fc785e9b9b1_1719911468164551.jpg','서울 용산구 보광로12길 4','MONTHLY','OFFICE','ONEROOM'),(28.38,_binary '\0',37.4,127.096,11,39.36,2,3000,15,80,12,12,12,'1101호','wydku0kny','경기 성남시 분당구 판교동 511','https://d3q1v38zegevi7.cloudfront.net/roomImages/b8aa03c04c794c0fade47b3fac3d01da_KakaoTalk_20240426_120008998.jpg','경기 성남시 분당구 판교로 182','MONTHLY','OFFICE','ONEROOM'),(22.79,_binary '\0',37.558,126.928,3,32.23,2,2000,8,90,13,13,13,'302호','wydm8m4p6','서울 마포구 동교동 174-13','https://d3q1v38zegevi7.cloudfront.net/roomImages/0cf0b06afd8c41ef9a9ef8d33841a9da_KakaoTalk_20240426_120008998_03.jpg','서울 마포구 신촌로 14','MONTHLY','FLAT','ONEROOM'),(26.92,_binary '\0',37.5577,126.928,7,42.38,2,1000,15,110,14,14,14,'701호','wydm8m4j7','서울 마포구 동교동 175-17','https://d3q1v38zegevi7.cloudfront.net/roomImages/8e9e0171bea44f908bcd4476f0e2b887_1718412744540739.jpg','서울 마포구 신촌로2길 5-10','MONTHLY','OFFICE','TWOROOM'),(27.31,_binary '\0',37.5587,126.93,2,31.56,2,1000,8,90,15,15,15,'202호','wydm8m772','서울 서대문구 창천동 504-11','https://d3q1v38zegevi7.cloudfront.net/roomImages/9dce2768666e4bf09bc2ab30d8a4541f_1719911428036050.jpg','서울 서대문구 신촌로3가길 3-8','MONTHLY','OFFICE','ONEROOM'),(26.92,_binary '\0',37.557,126.929,1,39.36,2,1000,15,80,16,16,16,'103호','wydm8m499','서울 마포구 동교동 177-2','https://d3q1v38zegevi7.cloudfront.net/roomImages/a22b2f3812bd436eafcfc611171a1563_1718412745132824.jpg','서울 마포구 신촌로2안길 30','MONTHLY','OFFICE','ONEROOM'),(26.92,_binary '\0',37.558,126.983,3,44.79,3,22500,8,0,17,17,17,'305호','wydm9t4x1','서울 중구 회현동2가 41-4','https://d3q1v38zegevi7.cloudfront.net/roomImages/778e242c153646d0869e276ab4894274_S_92551712298774uo.jpg','서울 중구 소공로4길 3','JEONSE','OFFICE','SEPERATED'),(35.62,_binary '\0',37.5589,126.984,9,45.79,3,3000,15,90,18,18,18,'902호','wydm9t6u2','서울 중구 회현동2가 19-1','https://d3q1v38zegevi7.cloudfront.net/roomImages/df908752fbcb401d90597fa17308795c_20240426_114932.jpg','서울 중구 소공로6길 13-7','MONTHLY','OFFICE','TWOROOM'),(28.38,_binary '\0',37.4835,126.947,2,39.36,3,2000,10,65,19,19,19,'201호','wydm0z8hb','서울 관악구 봉천동 889-26','https://d3q1v38zegevi7.cloudfront.net/roomImages/059940962b9740d8b1fa1664cde21d98_3889bba6947a78857b8e3813371db3d56f1033d2.jpg','서울 관악구 양녕로2가길 1','MONTHLY','OFFICE','ONEROOM'),(29.11,_binary '\0',37.4837,126.947,1,36.21,3,2000,8,70,20,20,20,'103호','wydm0z8nx','서울 관악구 봉천동 891-41','https://d3q1v38zegevi7.cloudfront.net/roomImages/a4b31e8cd57e469e9e84507425a1e507_2024071911420627_17616_wt.jpg','서울 관악구 양녕로2가길 8','MONTHLY','FLAT','ONEROOM'),(26.92,_binary '\0',37.4834,126.947,1,32.23,3,2000,5,66,21,21,21,'101호','wydm0z8hz','서울 관악구 봉천동 891-34','https://d3q1v38zegevi7.cloudfront.net/roomImages/01ad9b6b9bd34820824d6cecb4c3911d_2024071517512343_17616_wt.jpg','서울 관악구 양녕로2길 11','MONTHLY','FLAT','ONEROOM'),(28.12,_binary '\0',37.4739,126.953,1,36.21,3,1000,8,80,22,22,22,'102호','wydm0vuts','서울 관악구 봉천동 1594-7','https://d3q1v38zegevi7.cloudfront.net/roomImages/cfc186f4f5ba49ea927f64180ae86598_KakaoTalk_20240330_143701544_06.jpg','서울 관악구 관악로 98','MONTHLY','FLAT','ONEROOM'),(26.92,_binary '\0',37.5484,127.069,2,39.36,3,1000,6,80,23,23,23,'204호','wydmee2z3','','https://d3q1v38zegevi7.cloudfront.net/roomImages/d076727db8c8482ca384e6ded4c7832b_1719911468164551.jpg','서울 광진구 광나루로 351','MONTHLY','FLAT','ONEROOM'),(26.92,_binary '\0',37.5308,127.085,2,32.23,3,1000,6,70,24,24,24,'202호','wydmebkc0','서울 광진구 자양동 678-28','https://d3q1v38zegevi7.cloudfront.net/roomImages/bdc90a0c03f14a9c9943be1cb4e013cf_KakaoTalk_20240330_143701544_06.jpg','서울 광진구 자양로3길 14-3','MONTHLY','FLAT','TWOROOM');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 22:04:28
